echo 'Creating Global moshell luncher'
echo
cat > /data/data/com.termux/files/usr/bin/moshell <<'EOF'
#!/usr/bin/env bash
MOSHELL_DIR="/root/moshell"
DISTRO="debian"

clear
echo "-------------------------------------------"
echo "Launching Moshell"
echo "-------------------------------------------"
echo "Version 25.0j"
echo "-----------------------------------------"
echo "Edited & Rewrite by ZWE (Z-H-L)"
echo "------------------------------------------"
sleep 2

if [ -z "$1" ]; then
    MODE="offline"
else
    MODE="connect"
fi

if [ "$MODE" = "offline" ]; then
    exec proot-distro login "$DISTRO" -- bash -lc "
        cd '$MOSHELL_DIR' && exec bash ./moshell -offline
    "
else
    exec proot-distro login "$DISTRO" -- bash -lc "
        cd '$MOSHELL_DIR' && exec bash ./moshell \"$@\"
    "
fi
EOF

chmod +x /data/data/com.termux/files/usr/bin/moshell

