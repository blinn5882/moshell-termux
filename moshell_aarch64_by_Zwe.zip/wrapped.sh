#!/bin/bash
# wrap_x86_execs_box64.sh
# Find ELF x86-64 executables under /root/moshell (exclude *.so*, *.dll, *.exe)
# Dry-run by default; pass --apply to perform changes.
# Usage:
#   /root/wrap_x86_execs_box64.sh         # dry run, lists candidates
#   /root/wrap_x86_execs_box64.sh --apply # rename -> .real and create wrapper

set -euo pipefail

MOSHELL_DIR="/root/moshell"
EXCLUDE_PATTERNS=( '*.so*' '*.dll' '*.exe' )
DRYRUN=1

if [ "${1:-}" = "--apply" ]; then
  DRYRUN=0
fi

echo "[INFO] Searching for executable candidates under $MOSHELL_DIR ..."
# build find exclude args
FEXC=()
for p in "${EXCLUDE_PATTERNS[@]}"; do
  FEXC+=( ! -name "$p" )
done

# fast candidate list: any file with exec bit (skip excluded names)
# store relative paths for speed
TMP_LIST="/root/moshell_work/all_exec_candidates.txt"
mkdir -p /root/moshell_work
: > "$TMP_LIST"

# collect candidates (fast)
( cd "$MOSHELL_DIR" \
  && find . -type f -perm -111 "${FEXC[@]}" -print0 ) | xargs -0 -n1 -I{} bash -c 'echo "{}"' > "$TMP_LIST"

# function to test if file is ELF x86_64 by reading header bytes (fast)
is_x86_64() {
  local file="$1"
  # check ELF magic
  if ! head -c 4 "$file" 2>/dev/null | grep -q $'\x7fELF'; then
    return 1
  fi
  # read e_machine (bytes 18-19, little endian)
  # output as hex without spaces
  local em
  em=$(od -An -t x1 -j 18 -N 2 "$file" 2>/dev/null | tr -d ' \t\n')
  # For x86_64 e_machine = 0x3e => bytes are 3e 00 on little-endian
  if [ "$em" = "3e00" ] || [ "$em" = "003e" ]; then
    return 0
  fi
  return 1
}

CANDLIST="/root/moshell_work/x86_execs_to_wrap.txt"
: > "$CANDLIST"
count=0

while IFS= read -r rel; do
  # absolute path
  f="$MOSHELL_DIR/${rel#./}"
  # skip if already .real
  if [[ "$f" == *.real ]]; then
    continue
  fi
  # quick skip: if name matches excludes (redundant), continue
  base=$(basename "$f")
  case "$base" in
    *.so*|*.dll|*.exe) continue ;;
  esac

  if is_x86_64 "$f"; then
    echo "[FOUND] $f"
    echo "$f" >> "$CANDLIST"
    count=$((count+1))
  fi
done < "$TMP_LIST"

echo ""
echo "[SUMMARY] Found $count x86_64 ELF executable(s)."
echo "List written to: $CANDLIST"
if [ $count -eq 0 ]; then
  exit 0
fi

if [ $DRYRUN -eq 1 ]; then
  echo ""
  echo "DRY RUN only. To apply changes, run:"
  echo "  $0 --apply"
  exit 0
fi

# APPLY: perform rename -> .real and create wrapper
echo ""
echo "[APPLY] Renaming originals to *.real and writing wrappers..."

while IFS= read -r f; do
  # sanity: file still exists?
  if [ ! -f "$f" ]; then
    echo "[SKIP] missing: $f"
    continue
  fi
  # rename original to .real if not already
  real="${f}.real"
  if [ ! -f "$real" ]; then
    mv -v -- "$f" "$real"
  else
    echo "[KEEP] real already exists: $real"
  fi

  # create wrapper at original path (only if not exists)
  if [ -e "$f" ]; then
    echo "[SKIP] wrapper already present at $f"
    continue
  fi

  cat > "$f" <<EOF
#!/bin/bash
# wrapper auto-generated to run original under box64
exec box64 "$real" "\$@"
EOF

  chmod +x "$f"
  echo "[WRAPPED] $f -> box64 $real"
done < "$CANDLIST"

echo ""
echo "[DONE] Wrapping completed. Verify with: ls -l $MOSHELL_DIR/** | grep .real"
exit 0
