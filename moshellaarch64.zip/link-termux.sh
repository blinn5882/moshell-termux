echo "Creating global Moshell launcher..."
sleep 3

# Create a simple wrapper script inside Termux
cat > $PREFIX/bin/moshell <<'EOF'
#!/bin/bash
# Moshell launcher for Termux
echo "-------------------------------------------"
echo "Launching Moshell"
echo "-------------------------------------------"
echo "Version 25.0j"
echo "-----------------------------------------"
echo "Edited & Rewrite by ZWE (Z-H-L)"
echo "------------------------------------------""
# Adjust path if your Moshell is in /root/moshell inside Debian
proot-distro login debian -- bash -c "cd /root/moshell && ./moshell"
EOF

# Make launcher executable
chmod +x $PREFIX/bin/moshell
clear
echo "✅ Moshell launcher created!"
echo
echo "Now you can simply type in termux: moshell"
sleep 5

