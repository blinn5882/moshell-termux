find /root/moshell -type f -exec grep -El 'uname[a-zA-Z0-9_]*=\$\(uname -a\)' {} \; | while read -r file; do
    sed -i -E 's|uname[a-zA-Z0-9_]*=\$\(uname -a\)|unamea=Linux-x86_64|' "$file"
    echo "✔ Patched: $file"
done
