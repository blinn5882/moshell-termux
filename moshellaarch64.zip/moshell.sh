#!/bin/bash
set -e
clear
echo
echo '#########################'
echo '#  Moshell for Android  #'
echo '#        (aarch64)      #'
echo '#########################'
echo
echo '#########################'
echo '# If you fonud any bugs #'
echo '#    plz send to me     #'
echo '#########################'
echo
echo '#########################'
echo '#Version-25.0j..........#'
echo '#Edited by ZWE (Z-H-L)--#'
echo '#########################'
echo
read -n 1 -s -r -p "Press any key to start installation..."
echo

# Termux prerequisites
pkg update -y && pkg upgrade -y
pkg install -y curl nano wget proot-distro python unzip

# Install Debian container (skip if already installed)
proot-distro install debian || true

echo
echo '#################################'
echo '# Debian installed successfully #'
echo '#################################'
echo

# Enter Debian environment
proot-distro login debian -- bash <<'EOF'
set -e
clear

echo '#########################'
echo '#Updating Debian system.#'
echo '#########################'
apt update -y && apt upgrade -y
clear
echo '###############################'
echo '#Installing required packages.#'
echo '###############################'
apt install -y sudo curl perl gpg build-essential openjdk-21-jdk unzip zip make cmake wget gdown || true
clear
echo '##########################'
echo '#Adding Box64 repository.#'
echo '##########################'
echo
sleep 3
wget -qO- https://ryanfortner.github.io/box64-debs/KEY.gpg | gpg --dearmor -o /etc/apt/trusted.gpg.d/box64-debs-archive-keyring.gpg || echo "warn"
wget -q https://ryanfortner.github.io/box64-debs/box64.list -O /etc/apt/sources.list.d/box64.list || echo "warn"

apt update -y || true
apt install -y box64-android || echo "warn: box64 install failed"

# --- x86_64 environment in /root ---
X64ROOT=/root/x86_64-root
mkdir -p "$X64ROOT"/{lib,lib64,usr/bin,usr/lib,usr/lib64,tmp}
cd "$X64ROOT/lib" || { echo "Cannot cd to $X64ROOT/lib"; exit 1; }
clear
echo '#########################################'
echo '#Downloading required x86_64 libraries..#'
echo '#########################################'
echo
sleep 3
wget --show-progress https://security.debian.org/debian-security/pool/updates/main/g/glibc/libc6_2.31-13+deb11u13_amd64.deb
wget --show-progress http://ftp.us.debian.org/debian/pool/main/n/ncurses/libncurses6_6.2+20201114-2+deb11u2_amd64.deb
wget --show-progress http://ftp.us.debian.org/debian/pool/main/r/readline/libreadline8_8.1-1_amd64.deb
wget --show-progress http://ftp.us.debian.org/debian/pool/main/g/gcc-10/libstdc++6_10.2.1-6_amd64.deb
clear
echo '###############################################'
echo '#Fixing permissions and extracting libraries..#'
echo '###############################################'
echo
sleep 3
chmod 644 ./*.deb
chown root:root ./*.deb 2>/dev/null || true

for f in ./*.deb; do
    echo "Extracting $f ..."
    dpkg-deb -x "$f" "$X64ROOT" || echo "⚠️ Failed to extract $f (continuing)"
done
clear
echo '#########################################'
echo '#Exporting x86_64 environment variables.#'
echo '#########################################'
echo
export BOX64_PATH="$X64ROOT/usr/bin:$X64ROOT/bin"
export BOX64_LD_LIBRARY_PATH="$X64ROOT/lib:$X64ROOT/usr/lib:$X64ROOT/usr/lib/x86_64-linux-gnu"
export BOX64_BASH=1
aleep 3
echo '____________________________'
echo '✅ x86_64 environment ready!'
echo '____________________________'
sleep 4
clear
# --- Moshell download ---
echo '#####################'
echo '#Downloading Moshell#'
echo '#####################'
cd ~/
sleep 3
gdown https://drive.google.com/uc?id=1YkdtDvGnAHBGqCnSJdlEv5T2TqXXoHDu || echo "⚠️ gdown failed"

echo "Unzipping Moshell..."
unzip -o moshellaarch64.zip || echo "⚠️ unzip failed"
echo
echo "Installing Moshell..."
sleep 3
bash moshell_install.sh
0
~/
y
y

cd ~/
rm -r moshellaarch64.zip
rm -r moshell_install
echo
echo '✅ Moshell installation completed!'
echo
sleep 3
clear
echo '#################################'
echo '#Patching Moshell libraries.....#'
echo '#################################'
echo
aleep 3
chmod +x patched.sh
bash patched.sh
echo '____________________'
echo 'Patch comlpete'
echo '____________________'
echo
sleep 3
clear
echo '###################################'
echo '#wrapping moshell libraries.......#'
echo
echo '#this step take more times........#'
echo
echo '#Please do not turn off the screen#'
echo '###################################'
echo
sleep 3
chmod +x wrapped.sh
bash wrapped.sh
echo
clear
rm -r wrapped.sh patched.sh
cd ~/
chmod +x link-termux.sh
bash link-termux.sh
echo
clear
cd ~/moshell/commonjars
mv nc6.lin64 nc6
mv ssh.lin64 ssh
chmod +x nc6
chmod +x ssh
cd ~/
echo '----------------------------------'
echo 'Logging out from Debian'
echo '----------------------------------'
echo
EOF
echo '-------------------------'
echo 'Installation complete! 🎉'
echo '-------------------------'
echo 
read -n 1 -s -r -p 'Press any key to exit installer...'
clear
exit 0

